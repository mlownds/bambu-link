#!/bin/bash

# Bambu Link Uninstallation Script
# This script removes all files and services installed by bambu-link-install.sh

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_question() {
    echo -e "${BLUE}[QUESTION]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

print_status "Starting Bambu Link uninstallation..."

# Function to ask for confirmation
confirm_action() {
    local message="$1"
    local default="${2:-n}"
    
    if [ "$default" = "y" ]; then
        prompt="[Y/n]"
    else
        prompt="[y/N]"
    fi
    
    while true; do
        print_question "$message $prompt: "
        read -r response
        
        # Use default if no response
        if [ -z "$response" ]; then
            response="$default"
        fi
        
        case "$response" in
            [Yy]|[Yy][Ee][Ss])
                return 0
                ;;
            [Nn]|[Nn][Oo])
                return 1
                ;;
            *)
                print_warning "Please answer yes or no."
                ;;
        esac
    done
}

# Check if service exists
SERVICE_EXISTS=false
if systemctl list-unit-files bambu-link.service >/dev/null 2>&1; then
    SERVICE_EXISTS=true
fi

# Stop and disable service if it exists
if [ "$SERVICE_EXISTS" = true ]; then
    print_status "Found bambu-link service"
    
    # Check if service is running
    if systemctl is-active --quiet bambu-link.service; then
        print_status "Stopping bambu-link service..."
        systemctl stop bambu-link.service
        print_status "Service stopped"
    else
        print_status "Service is not running"
    fi
    
    # Check if service is enabled
    if systemctl is-enabled --quiet bambu-link.service; then
        print_status "Disabling bambu-link service..."
        systemctl disable bambu-link.service
        print_status "Service disabled"
    else
        print_status "Service is not enabled"
    fi
    
    # Remove service file
    if [ -f "/etc/systemd/system/bambu-link.service" ]; then
        print_status "Removing systemd service file..."
        rm -f /etc/systemd/system/bambu-link.service
        print_status "Service file removed"
    fi
    
    # Reload systemd daemon
    print_status "Reloading systemd daemon..."
    systemctl daemon-reload
    systemctl reset-failed bambu-link.service 2>/dev/null || true
else
    print_status "No bambu-link service found"
fi

# Remove application files
if [ -d "/opt/bambu-link" ]; then
    if confirm_action "Remove application files from /opt/bambu-link?"; then
        print_status "Removing /opt/bambu-link directory..."
        rm -rf /opt/bambu-link
        print_status "Application files removed"
    else
        print_warning "Skipping removal of application files"
    fi
else
    print_status "No application files found in /opt/bambu-link"
fi

# Handle configuration files
CONFIG_REMOVED=false
if [ -f "/etc/bambu-link/config.ini" ]; then
    if confirm_action "Remove configuration file /etc/bambu-link/config.ini? (This will delete your settings)"; then
        print_status "Removing configuration file..."
        rm -f /etc/bambu-link/config.ini
        CONFIG_REMOVED=true
        print_status "Configuration file removed"
    else
        print_warning "Configuration file preserved at /etc/bambu-link/config.ini"
    fi
fi

# Remove config directory if empty or if config was removed
if [ -d "/etc/bambu-link" ]; then
    if [ "$CONFIG_REMOVED" = true ] || [ -z "$(ls -A /etc/bambu-link)" ]; then
        print_status "Removing empty configuration directory..."
        rmdir /etc/bambu-link 2>/dev/null || {
            print_warning "Could not remove /etc/bambu-link (directory not empty)"
        }
    else
        print_status "Configuration directory preserved (contains files)"
    fi
fi

# Check for any remaining processes
print_status "Checking for any remaining bambu-link processes..."
PROCESSES=$(pgrep -f "daemon.py\|bambu-link" 2>/dev/null || true)
if [ -n "$PROCESSES" ]; then
    print_warning "Found running processes related to bambu-link:"
    ps -p $PROCESSES -o pid,ppid,cmd 2>/dev/null || true
    
    if confirm_action "Kill these processes?"; then
        print_status "Terminating processes..."
        kill $PROCESSES 2>/dev/null || true
        sleep 2
        # Force kill if still running
        kill -9 $PROCESSES 2>/dev/null || true
        print_status "Processes terminated"
    fi
else
    print_status "No running bambu-link processes found"
fi

# Summary
print_status "Uninstallation completed!"
echo
print_status "Summary of actions taken:"
echo "  - Stopped and disabled bambu-link service"
echo "  - Removed systemd service file"
echo "  - Reloaded systemd daemon"

if [ -d "/opt/bambu-link" ]; then
    echo "  - Application files preserved at /opt/bambu-link"
else
    echo "  - Removed application files from /opt/bambu-link"
fi

if [ -f "/etc/bambu-link/config.ini" ]; then
    echo "  - Configuration file preserved at /etc/bambu-link/config.ini"
else
    echo "  - Removed configuration files"
fi

echo
if [ -d "/opt/bambu-link" ] || [ -f "/etc/bambu-link/config.ini" ]; then
    print_warning "Some files were preserved. Run this script again to remove them."
else
    print_status "All bambu-link files have been removed from the system."
fi

print_status "Uninstallation process finished."