#!/bin/bash

# Bambu Link Installation Script
# This script extracts files from a tarball and installs the Bambu Link service

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

TARBALL="impl.tar"

# Check if tarball exists
if [ ! -f "$TARBALL" ]; then
    print_error "Tarball file '$TARBALL' not found!"
    exit 1
fi

print_status "Starting Bambu Link installation..."

# Create temporary extraction directory
TEMP_DIR=$(mktemp -d)
print_status "Created temporary directory: $TEMP_DIR"

# Extract tarball
print_status "Extracting tarball: $TARBALL"
tar -xf "$TARBALL" -C "$TEMP_DIR"

# Find the extracted directory (assuming single top-level directory)
EXTRACTED_DIR=$(find "$TEMP_DIR" -mindepth 1 -maxdepth 1 -type d | head -n 1)

if [ -z "$EXTRACTED_DIR" ]; then
    # If no directory found, assume files are in temp dir root
    EXTRACTED_DIR="$TEMP_DIR"
fi

print_status "Working with extracted files in: $EXTRACTED_DIR"

# Create target directories
print_status "Creating target directories..."
mkdir -p /opt/bambu-link
mkdir -p /etc/bambu-link

# Install daemon.py
if [ -f "$EXTRACTED_DIR/daemon.py" ]; then
    print_status "Installing daemon.py to /opt/bambu-link/"
    cp "$EXTRACTED_DIR/daemon.py" /opt/bambu-link/
    chmod 755 /opt/bambu-link/daemon.py
else
    print_error "daemon.py not found in tarball!"
    exit 1
fi

# Install bambulabs_api_invio folder
if [ -d "$EXTRACTED_DIR/bambulabs_api_invio" ]; then
    print_status "Installing bambulabs_api_invio folder to /opt/bambu-link/"
    cp -r "$EXTRACTED_DIR/bambulabs_api_invio" /opt/bambu-link/
    chmod -R 755 /opt/bambu-link/bambulabs_api_invio
else
    print_error "bambulabs_api_invio folder not found in tarball!"
    exit 1
fi

# Install paho folder
if [ -d "$EXTRACTED_DIR/paho" ]; then
    print_status "Installing paho folder to /opt/bambu-link/"
    cp -r "$EXTRACTED_DIR/paho" /opt/bambu-link/
    chmod -R 755 /opt/bambu-link/paho
else
    print_error "paho folder not found in tarball!"
    exit 1
fi

# Install config.ini
if [ -f "$EXTRACTED_DIR/config.ini" ]; then
    print_status "Installing config.ini to /etc/bambu-link/"
    cp "$EXTRACTED_DIR/config.ini" /etc/bambu-link/config.ini
    chmod 666 /etc/bambu-link/config.ini  # Globally writable
    print_warning "config.ini is set as globally writable (666 permissions)"
else
    print_error "config.ini not found in tarball!"
    exit 1
fi

# Install systemd service file
if [ -f "$EXTRACTED_DIR/bambu-link.service" ]; then
    print_status "Installing systemd service file..."
    cp "$EXTRACTED_DIR/bambu-link.service" /etc/systemd/system/
    chmod 644 /etc/systemd/system/bambu-link.service
else
    print_error "bambu-link.service not found in tarball!"
    exit 1
fi

# Set ownership (optional - adjust as needed)
print_status "Setting file ownership..."
chown -R root:root /opt/bambu-link
chown root:root /etc/bambu-link/config.ini

# Reload systemd daemon
print_status "Reloading systemd daemon..."
systemctl daemon-reload

# Enable the service
print_status "Enabling bambu-link service..."
systemctl enable bambu-link.service

# Start the service
print_status "Starting bambu-link service..."
systemctl start bambu-link.service

# Check service status
if systemctl is-active --quiet bambu-link.service; then
    print_status "Bambu Link service is running successfully!"
else
    print_error "Failed to start bambu-link service. Check logs with: journalctl -u bambu-link.service"
    exit 1
fi

# Clean up temporary directory
print_status "Cleaning up temporary files..."
rm -rf "$TEMP_DIR"

print_status "Installation completed successfully!"
print_status "Service status: $(systemctl is-active bambu-link.service)"
print_status "To view logs: journalctl -u bambu-link.service"
print_status "To stop service: systemctl stop bambu-link.service"
print_status "To restart service: systemctl restart bambu-link.service"